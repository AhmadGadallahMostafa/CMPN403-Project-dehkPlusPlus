After each statment a newline character is needed for the parser to correctly recongize statments
so after each ; we need to have a new line either empty or that contains a new statment